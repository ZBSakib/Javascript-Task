function areaOfCircle(){
    var radius = window.prompt("Enter radius: ");
    
    var area = (3.141592653589793 * (radius) * (radius));
    console.log(area);
}
areaOfCircle()
