var intArray = [1, 2, 3, 4, 5, 6, 7,8,9];

function countsValues(intArray){
    var small = Math.min(...intArray);
    var big = Math.max(...intArray);
    var sum = intArray.reduce((a,b) => a + b, 0);
    var avg = sum / (intArray.length);
    console.log(small, big, sum, avg);
}
countsValues(intArray);