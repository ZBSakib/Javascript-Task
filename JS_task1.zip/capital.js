function convertToCapital()

{
    var name = prompt('Enter your name:');
    name = name.toUpperCase();
    console.log(name);
    document.getElementById("name").innerHTML = name;
}

convertToCapital();