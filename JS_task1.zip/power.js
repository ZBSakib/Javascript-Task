function powerOfNumbers(){
    var rows=window.prompt("Number of rows: ")
    for(let i = 0; i < rows; i++){
        console.log((i + 1) + " to the power of " + (i) +" is "+ (Math.pow((i+1), i)))
    }
}
powerOfNumbers();