function getAge(dateOfBirth) 
{
    var dateString = document.getElementById("birthdate").value;
    console.log(dateOfBirth);
    var today = new Date();
    var birthDate = new Date(dateString);
    var age = today.getFullYear() - birthDate.getFullYear();
    var a = today.getMonth() - birthDate.getMonth();
    if (a < 0 || (a === 0 && today.getDate() < birthDate.getDate())) 
    {
        age--;
    }
    console.log(age);
    return age;
}

getAge(dateOfBirth);